# Cursor test fixture
